package com.onestem6

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnCodeEditor).setOnClickListener {
            startActivity(Intent(this, CodeEditorActivity::class.java))
        }
        findViewById<Button>(R.id.btnCodeRunner).setOnClickListener {
            startActivity(Intent(this, CodeRunnerActivity::class.java))
        }
        findViewById<Button>(R.id.btnLearningTools).setOnClickListener {
            startActivity(Intent(this, LearningToolsActivity::class.java))
        }
        findViewById<Button>(R.id.btnPastQuestions).setOnClickListener {
            startActivity(Intent(this, PastQuestionsActivity::class.java))
        }
        findViewById<Button>(R.id.btnChat).setOnClickListener {
            startActivity(Intent(this, ChatActivity::class.java))
        }
    }
}
