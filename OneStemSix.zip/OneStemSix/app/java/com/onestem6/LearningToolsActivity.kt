package com.onestem6

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

/**
 * Learning Tools Screen
 * Features:
 *  - Flashcard creator & viewer (stored in SharedPreferences as JSON)
 *  - Quick notes pad
 *  - Topic reference links
 */
class LearningToolsActivity : AppCompatActivity() {

    // ── Flashcards ──────────────────────────────────────────────────────────
    private lateinit var etQuestion: EditText
    private lateinit var etAnswer: EditText
    private lateinit var btnAddCard: Button
    private lateinit var btnShowCard: Button
    private lateinit var tvFlashcard: TextView

    private var cards: JSONArray = JSONArray()
    private var currentCard = 0
    private var showingAnswer = false

    // ── Notes ────────────────────────────────────────────────────────────────
    private lateinit var etNotes: EditText
    private lateinit var btnSaveNotes: Button

    // ── Reference topics ─────────────────────────────────────────────────────
    private lateinit var topicSpinner: Spinner
    private lateinit var btnOpenTopic: Button

    private val topics = mapOf(
        "Python Docs"       to "https://docs.python.org/3/",
        "Kotlin Docs"       to "https://kotlinlang.org/docs/home.html",
        "C++ Reference"     to "https://en.cppreference.com/",
        "JavaScript MDN"    to "https://developer.mozilla.org/en-US/docs/Web/JavaScript",
        "Data Structures"   to "https://www.geeksforgeeks.org/data-structures/",
        "Algorithms"        to "https://www.geeksforgeeks.org/fundamentals-of-algorithms/",
        "Git Cheat Sheet"   to "https://education.github.com/git-cheat-sheet-education.pdf"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_learning_tools)

        initFlashcards()
        initNotes()
        initTopics()
    }

    // ── Flashcard logic ───────────────────────────────────────────────────────
    private fun initFlashcards() {
        etQuestion  = findViewById(R.id.etQuestion)
        etAnswer    = findViewById(R.id.etAnswer)
        btnAddCard  = findViewById(R.id.btnAddCard)
        btnShowCard = findViewById(R.id.btnShowCard)
        tvFlashcard = findViewById(R.id.tvFlashcard)

        loadCards()

        btnAddCard.setOnClickListener {
            val q = etQuestion.text.toString().trim()
            val a = etAnswer.text.toString().trim()
            if (q.isEmpty() || a.isEmpty()) {
                Toast.makeText(this, "Enter both question and answer", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val card = JSONObject().apply { put("q", q); put("a", a) }
            cards.put(card)
            saveCards()
            etQuestion.setText(""); etAnswer.setText("")
            Toast.makeText(this, "Card added! Total: ${cards.length()}", Toast.LENGTH_SHORT).show()
        }

        btnShowCard.setOnClickListener {
            if (cards.length() == 0) {
                tvFlashcard.text = "No flashcards yet. Add some above!"
                return@setOnClickListener
            }
            if (!showingAnswer) {
                val card = cards.getJSONObject(currentCard)
                tvFlashcard.text = "Q: ${card.getString("q")}\n\n(Tap again to see answer)"
                showingAnswer = true
            } else {
                val card = cards.getJSONObject(currentCard)
                tvFlashcard.text = "Q: ${card.getString("q")}\n\nA: ${card.getString("a")}\n\n[Card ${currentCard + 1}/${cards.length()}]"
                currentCard = (currentCard + 1) % cards.length()
                showingAnswer = false
            }
        }
    }

    private fun loadCards() {
        val prefs = getSharedPreferences("learning", MODE_PRIVATE)
        val json  = prefs.getString("flashcards", "[]") ?: "[]"
        cards = JSONArray(json)
    }

    private fun saveCards() {
        getSharedPreferences("learning", MODE_PRIVATE)
            .edit().putString("flashcards", cards.toString()).apply()
    }

    // ── Notes logic ───────────────────────────────────────────────────────────
    private fun initNotes() {
        etNotes      = findViewById(R.id.etNotes)
        btnSaveNotes = findViewById(R.id.btnSaveNotes)

        val prefs = getSharedPreferences("learning", MODE_PRIVATE)
        etNotes.setText(prefs.getString("notes", ""))

        btnSaveNotes.setOnClickListener {
            prefs.edit().putString("notes", etNotes.text.toString()).apply()
            Toast.makeText(this, "Notes saved ✓", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Topic reference logic ─────────────────────────────────────────────────
    private fun initTopics() {
        topicSpinner = findViewById(R.id.topicSpinner)
        btnOpenTopic = findViewById(R.id.btnOpenTopic)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, topics.keys.toList())
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        topicSpinner.adapter = adapter

        btnOpenTopic.setOnClickListener {
            val topic = topicSpinner.selectedItem.toString()
            val url   = topics[topic] ?: return@setOnClickListener
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            startActivity(intent)
        }
    }
}
