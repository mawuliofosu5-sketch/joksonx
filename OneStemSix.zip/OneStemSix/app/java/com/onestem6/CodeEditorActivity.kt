package com.onestem6

import android.os.Bundle
import android.text.Editable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class CodeEditorActivity : AppCompatActivity() {

    private lateinit var codeInput: EditText
    private lateinit var languageSpinner: Spinner
    private lateinit var btnSave: Button
    private lateinit var btnClear: Button

    private val languages = listOf("Python", "Java/Kotlin", "C/C++", "JavaScript")

    // Basic keyword sets per language
    private val keywords = mapOf(
        "Python"      to listOf("def","class","import","from","return","if","elif","else","for","while","in","not","and","or","True","False","None","print","range","len","self"),
        "Java/Kotlin" to listOf("fun","val","var","class","object","interface","import","return","if","else","when","for","while","override","private","public","protected","companion","data","sealed","suspend","lateinit","by","in","is","as","null","true","false"),
        "C/C++"       to listOf("int","float","double","char","void","return","if","else","for","while","do","switch","case","break","continue","include","define","struct","class","public","private","protected","new","delete","nullptr","true","false"),
        "JavaScript"  to listOf("function","const","let","var","return","if","else","for","while","class","import","export","default","new","this","null","undefined","true","false","async","await","=>","typeof","instanceof")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_code_editor)

        codeInput      = findViewById(R.id.codeInput)
        languageSpinner = findViewById(R.id.languageSpinner)
        btnSave        = findViewById(R.id.btnSave)
        btnClear       = findViewById(R.id.btnClear)

        // Populate language spinner
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, languages)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        languageSpinner.adapter = adapter

        // Live syntax highlighting
        codeInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                s ?: return
                applySyntaxHighlight(s.toString())
            }
        })

        btnSave.setOnClickListener {
            val lang = languageSpinner.selectedItem.toString()
            val code = codeInput.text.toString()
            // Save to SharedPreferences keyed by language
            val prefs = getSharedPreferences("saved_code", MODE_PRIVATE)
            prefs.edit().putString("code_$lang", code).apply()
            Toast.makeText(this, "Code saved!", Toast.LENGTH_SHORT).show()
        }

        btnClear.setOnClickListener {
            codeInput.setText("")
        }

        // Restore previously saved code when language changes
        languageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: android.view.View?, pos: Int, id: Long) {
                val lang = languages[pos]
                val prefs = getSharedPreferences("saved_code", MODE_PRIVATE)
                val saved = prefs.getString("code_$lang", "")
                codeInput.setText(saved)
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    private fun applySyntaxHighlight(code: String) {
        val lang = languageSpinner.selectedItem?.toString() ?: return
        val kwList = keywords[lang] ?: return

        // Remove existing spans safely
        val spannable = SpannableString(code)
        val keywordColor = ContextCompat.getColor(this, android.R.color.holo_blue_light)
        val stringColor  = ContextCompat.getColor(this, android.R.color.holo_green_light)
        val commentColor = ContextCompat.getColor(this, android.R.color.darker_gray)

        // Highlight keywords
        for (kw in kwList) {
            var start = 0
            while (true) {
                val idx = code.indexOf(kw, start)
                if (idx == -1) break
                val end = idx + kw.length
                // Ensure it's a whole word
                val before = if (idx > 0) code[idx - 1] else ' '
                val after  = if (end < code.length) code[end] else ' '
                if (!before.isLetterOrDigit() && !after.isLetterOrDigit()) {
                    spannable.setSpan(ForegroundColorSpan(keywordColor), idx, end, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                start = end
            }
        }

        // Highlight strings (double-quoted)
        var i = 0
        while (i < code.length) {
            if (code[i] == '"') {
                val end = code.indexOf('"', i + 1)
                if (end != -1) {
                    spannable.setSpan(ForegroundColorSpan(stringColor), i, end + 1, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE)
                    i = end + 1
                    continue
                }
            }
            i++
        }

        // Highlight single-line comments
        val commentPrefix = when (lang) {
            "Python" -> "#"
            else     -> "//"
        }
        code.lines().fold(0) { offset, line ->
            val ci = line.indexOf(commentPrefix)
            if (ci != -1) {
                spannable.setSpan(ForegroundColorSpan(commentColor), offset + ci, offset + line.length, SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            offset + line.length + 1
        }

        // Apply without triggering the TextWatcher again
        codeInput.removeTextChangedListener(null)
        val selection = codeInput.selectionStart
        codeInput.text = Editable.Factory.getInstance().newEditable(spannable)
        try { codeInput.setSelection(selection.coerceIn(0, codeInput.text.length)) } catch (_: Exception) {}
    }
}
