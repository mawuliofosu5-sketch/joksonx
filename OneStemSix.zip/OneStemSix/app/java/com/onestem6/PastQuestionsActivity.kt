package com.onestem6

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import org.json.JSONObject

data class Question(val topic: String, val question: String, val answer: String)

class PastQuestionsActivity : AppCompatActivity() {

    private lateinit var searchInput: EditText
    private lateinit var topicFilter: Spinner
    private lateinit var recyclerView: RecyclerView
    private lateinit var btnAddQ: Button

    private val allQuestions = mutableListOf<Question>()
    private var filtered = mutableListOf<Question>()
    private lateinit var adapter: QuestionAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_past_questions)

        searchInput  = findViewById(R.id.searchInput)
        topicFilter  = findViewById(R.id.topicFilter)
        recyclerView = findViewById(R.id.questionsRecycler)
        btnAddQ      = findViewById(R.id.btnAddQuestion)

        loadSeedData()
        loadUserQuestions()

        filtered = allQuestions.toMutableList()
        adapter = QuestionAdapter(filtered)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Topic filter
        val topics = listOf("All") + allQuestions.map { it.topic }.distinct().sorted()
        val topicAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, topics)
        topicAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        topicFilter.adapter = topicAdapter

        topicFilter.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, v: View?, pos: Int, id: Long) { applyFilter() }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        searchInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { applyFilter() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        // Add new question dialog
        btnAddQ.setOnClickListener { showAddDialog() }
    }

    private fun applyFilter() {
        val query = searchInput.text.toString().lowercase()
        val topic = topicFilter.selectedItem?.toString() ?: "All"
        filtered.clear()
        allQuestions.filter {
            (topic == "All" || it.topic == topic) &&
            (query.isEmpty() || it.question.lowercase().contains(query) || it.answer.lowercase().contains(query))
        }.let { filtered.addAll(it) }
        adapter.notifyDataSetChanged()
    }

    private fun showAddDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 20)
        }
        val etTopic = EditText(this).apply { hint = "Topic (e.g. Python)" }
        val etQ     = EditText(this).apply { hint = "Question" }
        val etA     = EditText(this).apply { hint = "Answer"; minLines = 3 }
        layout.addView(etTopic); layout.addView(etQ); layout.addView(etA)

        android.app.AlertDialog.Builder(this)
            .setTitle("Add Past Question")
            .setView(layout)
            .setPositiveButton("Save") { _, _ ->
                val t = etTopic.text.toString().trim()
                val q = etQ.text.toString().trim()
                val a = etA.text.toString().trim()
                if (t.isEmpty() || q.isEmpty() || a.isEmpty()) {
                    Toast.makeText(this, "All fields required", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                allQuestions.add(Question(t, q, a))
                saveUserQuestions()
                applyFilter()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Persistence ───────────────────────────────────────────────────────────
    private fun saveUserQuestions() {
        val arr = JSONArray()
        allQuestions.filter { it.topic != "SEED" }.forEach {
            arr.put(JSONObject().apply {
                put("topic", it.topic); put("q", it.question); put("a", it.answer)
            })
        }
        getSharedPreferences("pq", MODE_PRIVATE).edit().putString("questions", arr.toString()).apply()
    }

    private fun loadUserQuestions() {
        val prefs = getSharedPreferences("pq", MODE_PRIVATE)
        val arr   = JSONArray(prefs.getString("questions", "[]") ?: "[]")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            allQuestions.add(Question(o.getString("topic"), o.getString("q"), o.getString("a")))
        }
    }

    // ── Seed/demo data ────────────────────────────────────────────────────────
    private fun loadSeedData() {
        allQuestions.addAll(listOf(
            Question("Python",     "What is a list comprehension?",            "A concise way to create lists: [expr for item in iterable if condition]"),
            Question("Python",     "Difference between list and tuple?",       "Lists are mutable; tuples are immutable."),
            Question("Python",     "What does len() do?",                      "Returns the number of items in an object."),
            Question("Java/Kotlin","What is a data class in Kotlin?",          "A class that automatically generates equals(), hashCode(), toString(), and copy()."),
            Question("Java/Kotlin","Difference between val and var?",          "val is immutable (read-only); var is mutable."),
            Question("C/C++",      "What is a pointer?",                       "A variable that stores the memory address of another variable."),
            Question("C/C++",      "Difference between malloc and new?",       "malloc is C-style memory allocation; new is C++ and also calls the constructor."),
            Question("JavaScript", "What is a closure?",                       "A function that retains access to its outer scope even after the outer function returns."),
            Question("JavaScript", "Difference between == and ===?",           "== checks value with type coercion; === checks value AND type (strict equality)."),
            Question("Algorithms", "What is Big-O notation?",                  "A mathematical notation to describe the upper bound of algorithm time/space complexity."),
            Question("Algorithms", "Time complexity of binary search?",        "O(log n)"),
            Question("Data Structures","What is a stack?",                     "A LIFO (Last In First Out) data structure. Operations: push, pop, peek.")
        ))
    }
}

// ── RecyclerView Adapter ──────────────────────────────────────────────────────
class QuestionAdapter(private val items: List<Question>) :
    RecyclerView.Adapter<QuestionAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvTopic: TextView = v.findViewById(R.id.tvTopic)
        val tvQuestion: TextView = v.findViewById(R.id.tvQuestion)
        val tvAnswer: TextView = v.findViewById(R.id.tvAnswer)
        val btnToggle: Button = v.findViewById(R.id.btnToggle)
        var expanded = false
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_question, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val item = items[pos]
        h.tvTopic.text    = "[${item.topic}]"
        h.tvQuestion.text = item.question
        h.tvAnswer.text   = item.answer
        h.tvAnswer.visibility = if (h.expanded) View.VISIBLE else View.GONE
        h.btnToggle.text  = if (h.expanded) "Hide Answer" else "Show Answer"

        h.btnToggle.setOnClickListener {
            h.expanded = !h.expanded
            h.tvAnswer.visibility = if (h.expanded) View.VISIBLE else View.GONE
            h.btnToggle.text = if (h.expanded) "Hide Answer" else "Show Answer"
        }
    }

    override fun getItemCount() = items.size
}
