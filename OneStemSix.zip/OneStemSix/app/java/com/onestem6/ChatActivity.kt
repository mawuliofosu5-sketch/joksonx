package com.onestem6

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

/**
 * Offline Communication Screen
 *
 * This screen provides three offline communication modes:
 *
 * 1. LOCAL CHAT (Wi-Fi Direct / same LAN)
 *    - Uses Android NsdManager to discover peers on the same Wi-Fi network
 *    - Sends plain-text messages over TCP sockets (port 9999)
 *    - Full implementation scaffold is provided; wire up NsdManager in
 *      WifiDirectHelper.kt for production use.
 *
 * 2. BLUETOOTH MESSAGING
 *    - Uses BluetoothAdapter to scan and pair nearby devices
 *    - Sends messages via BluetoothSocket (RFCOMM)
 *    - Scaffold provided; see BluetoothHelper.kt for full SPP implementation.
 *
 * 3. LINK / FILE SHARING
 *    - Copies a shareable link or file path to the clipboard
 *    - Opens Android Share sheet so the user can send via any available app
 *      (WhatsApp, Telegram, NFC, etc.) — works even without the internet for
 *      local apps and Bluetooth/NFC-based sharing.
 *
 * NOTE: For a production-ready offline chat between two phones on the same
 * Wi-Fi without internet, use NsdManager + ServerSocket/Socket on port 9999.
 * The demo below simulates the UI and message flow locally.
 */
class ChatActivity : AppCompatActivity() {

    private lateinit var tabLocal: Button
    private lateinit var tabBluetooth: Button
    private lateinit var tabShare: Button

    private lateinit var panelLocal: LinearLayout
    private lateinit var panelBluetooth: LinearLayout
    private lateinit var panelShare: LinearLayout

    // Local chat
    private lateinit var chatLog: TextView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: Button
    private lateinit var tvStatus: TextView

    // Bluetooth
    private lateinit var btnScanBT: Button
    private lateinit var btDeviceList: ListView
    private lateinit var etBtMessage: EditText
    private lateinit var btnSendBt: Button
    private lateinit var tvBtLog: TextView

    // Share
    private lateinit var etShareLink: EditText
    private lateinit var btnCopyLink: Button
    private lateinit var btnShareLink: Button
    private lateinit var btnShareFile: Button

    private val messages = JSONArray()
    private val df = SimpleDateFormat("HH:mm", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        bindViews()
        setupTabs()
        setupLocalChat()
        setupBluetooth()
        setupShare()

        // Default tab
        showPanel("local")
    }

    private fun bindViews() {
        tabLocal     = findViewById(R.id.tabLocal)
        tabBluetooth = findViewById(R.id.tabBluetooth)
        tabShare     = findViewById(R.id.tabShare)

        panelLocal     = findViewById(R.id.panelLocal)
        panelBluetooth = findViewById(R.id.panelBluetooth)
        panelShare     = findViewById(R.id.panelShare)

        chatLog  = findViewById(R.id.chatLog)
        etMessage = findViewById(R.id.etMessage)
        btnSend  = findViewById(R.id.btnSend)
        tvStatus = findViewById(R.id.tvStatus)

        btnScanBT   = findViewById(R.id.btnScanBT)
        btDeviceList = findViewById(R.id.btDeviceList)
        etBtMessage = findViewById(R.id.etBtMessage)
        btnSendBt   = findViewById(R.id.btnSendBt)
        tvBtLog     = findViewById(R.id.tvBtLog)

        etShareLink  = findViewById(R.id.etShareLink)
        btnCopyLink  = findViewById(R.id.btnCopyLink)
        btnShareLink = findViewById(R.id.btnShareLink)
        btnShareFile = findViewById(R.id.btnShareFile)
    }

    private fun setupTabs() {
        tabLocal.setOnClickListener     { showPanel("local") }
        tabBluetooth.setOnClickListener { showPanel("bt") }
        tabShare.setOnClickListener     { showPanel("share") }
    }

    private fun showPanel(tab: String) {
        panelLocal.visibility     = if (tab == "local") LinearLayout.VISIBLE else LinearLayout.GONE
        panelBluetooth.visibility = if (tab == "bt")    LinearLayout.VISIBLE else LinearLayout.GONE
        panelShare.visibility     = if (tab == "share") LinearLayout.VISIBLE else LinearLayout.GONE
    }

    // ── LOCAL CHAT ────────────────────────────────────────────────────────────
    private fun setupLocalChat() {
        tvStatus.text = "🟢 Local demo mode (same device)"
        loadMessages()

        btnSend.setOnClickListener {
            val text = etMessage.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            appendMessage("Me", text)
            etMessage.setText("")
            // TODO: In production, send `text` via TCP socket to discovered peer
        }
    }

    private fun appendMessage(sender: String, text: String) {
        val msg = JSONObject().apply {
            put("sender", sender)
            put("text", text)
            put("time", df.format(Date()))
        }
        messages.put(msg)
        saveMessages()
        renderChat()
    }

    private fun renderChat() {
        val sb = StringBuilder()
        for (i in 0 until messages.length()) {
            val m = messages.getJSONObject(i)
            sb.appendLine("[${m.getString("time")}] ${m.getString("sender")}: ${m.getString("text")}")
        }
        chatLog.text = sb.toString()
    }

    private fun loadMessages() {
        val prefs = getSharedPreferences("chat", MODE_PRIVATE)
        val saved = JSONArray(prefs.getString("messages", "[]") ?: "[]")
        for (i in 0 until saved.length()) messages.put(saved.getJSONObject(i))
        renderChat()
    }

    private fun saveMessages() {
        getSharedPreferences("chat", MODE_PRIVATE)
            .edit().putString("messages", messages.toString()).apply()
    }

    // ── BLUETOOTH ─────────────────────────────────────────────────────────────
    private fun setupBluetooth() {
        btnScanBT.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN),
                    101
                )
                return@setOnClickListener
            }
            scanBluetooth()
        }

        btnSendBt.setOnClickListener {
            val msg = etBtMessage.text.toString().trim()
            if (msg.isEmpty()) return@setOnClickListener
            // TODO: Send via BluetoothSocket to paired/connected device
            tvBtLog.append("\n[${df.format(Date())}] Me → ${btDeviceList.checkedItemPosition}: $msg")
            etBtMessage.setText("")
            Toast.makeText(this, "BT send scaffold — wire BluetoothHelper for real send", Toast.LENGTH_SHORT).show()
        }
    }

    @Suppress("MissingPermission")
    private fun scanBluetooth() {
        val bt = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
        if (bt == null || !bt.isEnabled) {
            Toast.makeText(this, "Please enable Bluetooth first", Toast.LENGTH_SHORT).show()
            return
        }
        val bonded = bt.bondedDevices.map { "${it.name} (${it.address})" }.toMutableList()
        if (bonded.isEmpty()) bonded.add("No paired devices found")
        val listAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, bonded)
        btDeviceList.adapter = listAdapter
        btDeviceList.choiceMode = ListView.CHOICE_MODE_SINGLE
        Toast.makeText(this, "Found ${bonded.size} paired device(s)", Toast.LENGTH_SHORT).show()
    }

    // ── LINK / FILE SHARING ───────────────────────────────────────────────────
    private fun setupShare() {
        // Pre-fill with a sample class resource link
        etShareLink.setText("https://onestem6.class/resources")

        btnCopyLink.setOnClickListener {
            val link = etShareLink.text.toString()
            val clip = ClipData.newPlainText("Class Link", link)
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
            Toast.makeText(this, "Link copied to clipboard ✓", Toast.LENGTH_SHORT).show()
        }

        btnShareLink.setOnClickListener {
            val link = etShareLink.text.toString()
            val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_TEXT, "📚 One Stem Six Resource:\n$link")
            }
            startActivity(android.content.Intent.createChooser(intent, "Share link via…"))
        }

        btnShareFile.setOnClickListener {
            // Open file picker then share the selected file
            val intent = android.content.Intent(android.content.Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                addCategory(android.content.Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(android.content.Intent.createChooser(intent, "Pick a file to share"), 200)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 200 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = contentResolver.getType(uri) ?: "*/*"
                putExtra(android.content.Intent.EXTRA_STREAM, uri)
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(android.content.Intent.createChooser(shareIntent, "Share file via…"))
        }
    }
}
