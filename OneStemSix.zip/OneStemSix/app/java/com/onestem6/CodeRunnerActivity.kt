package com.onestem6

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/**
 * Code Runner Screen
 *
 * On-device execution is not possible for all languages without bundling an interpreter.
 * This activity provides:
 *  - A code editor panel
 *  - A "Run" button that routes to the appropriate online judge / REPL
 *  - A local output panel for simulated / pre-stored results (demo mode)
 *
 * For real execution you can embed:
 *  - Chaquopy (Python on Android)  → https://chaquo.com/chaquopy/
 *  - J2V8 (JavaScript V8 engine)   → https://github.com/eclipsesource/J2V8
 *  - A remote judge API            → e.g. Judge0 (https://judge0.com)
 */
class CodeRunnerActivity : AppCompatActivity() {

    private lateinit var codeInput: EditText
    private lateinit var languageSpinner: Spinner
    private lateinit var btnRun: Button
    private lateinit var outputView: TextView
    private lateinit var btnOpenRepl: Button

    private val languages = listOf("Python", "Java/Kotlin", "C/C++", "JavaScript")

    // Online REPLs for each language (opens in browser)
    private val replUrls = mapOf(
        "Python"      to "https://replit.com/languages/python3",
        "Java/Kotlin" to "https://play.kotlinlang.org/",
        "C/C++"       to "https://www.onlinegdb.com/online_c++_compiler",
        "JavaScript"  to "https://playcode.io/"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_code_runner)

        codeInput       = findViewById(R.id.runnerCodeInput)
        languageSpinner = findViewById(R.id.runnerLanguageSpinner)
        btnRun          = findViewById(R.id.btnRun)
        outputView      = findViewById(R.id.outputView)
        btnOpenRepl     = findViewById(R.id.btnOpenRepl)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, languages)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        languageSpinner.adapter = adapter

        // Demo runner — shows simulated output based on detected patterns
        btnRun.setOnClickListener {
            val code = codeInput.text.toString().trim()
            val lang = languageSpinner.selectedItem.toString()
            outputView.text = simulateRun(code, lang)
        }

        // Open real online REPL in browser
        btnOpenRepl.setOnClickListener {
            val lang = languageSpinner.selectedItem.toString()
            val url  = replUrls[lang] ?: "https://replit.com"
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
            startActivity(intent)
        }

        // Restore saved code from Code Editor screen
        languageSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: android.view.View?, pos: Int, id: Long) {
                val lang = languages[pos]
                val prefs = getSharedPreferences("saved_code", MODE_PRIVATE)
                codeInput.setText(prefs.getString("code_$lang", ""))
            }
            override fun onNothingSelected(parent: AdapterView<*>) {}
        }
    }

    /** Very basic pattern-based simulation for demo purposes */
    private fun simulateRun(code: String, lang: String): String {
        if (code.isBlank()) return "⚠️ No code to run."

        val sb = StringBuilder()
        sb.appendLine("▶ Running [$lang] …\n")

        when (lang) {
            "Python" -> {
                // Detect print statements
                val prints = Regex("""print\(["'](.+?)["']\)""").findAll(code)
                if (prints.none()) {
                    sb.appendLine("(No print() output detected in demo mode)")
                } else {
                    prints.forEach { sb.appendLine(it.groupValues[1]) }
                }
            }
            "JavaScript" -> {
                val logs = Regex("""console\.log\(["'`](.+?)["'`]\)""").findAll(code)
                if (logs.none()) {
                    sb.appendLine("(No console.log() output detected in demo mode)")
                } else {
                    logs.forEach { sb.appendLine(it.groupValues[1]) }
                }
            }
            else -> sb.appendLine("Demo mode: use 'Open REPL' to run $lang code online.")
        }

        sb.appendLine("\n✅ Done.")
        return sb.toString()
    }
}
